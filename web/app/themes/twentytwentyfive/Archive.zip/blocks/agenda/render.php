<?php
die("dsf");
$limit = get_field('limit') ?: 4;
$show_featured = get_field('show_featured');

// Featured
$featured = new WP_Query([
    'post_type' => 'agenda',
    'meta_key' => 'featured',
    'meta_value' => 1,
    'posts_per_page' => 1
]);
?>

<div class="agenda">

<?php if ($show_featured && $featured->have_posts()):
    $featured->the_post(); ?>

<div class="agenda-featured">
    <div>
        <span><?php the_field('start_date'); ?></span>
        <h2><?php the_title(); ?></h2>
        <p><?php the_field('location'); ?></p>
    </div>
    <img src="<?= get_field('image')['url']; ?>">
</div>

<?php endif; wp_reset_postdata(); ?>

<?php
$list = new WP_Query([
    'post_type' => 'agenda',
    'posts_per_page' => $limit
]);
?>

<div class="agenda-grid">

<?php while ($list->have_posts()): $list->the_post(); ?>

<div class="item">
    <img src="<?= get_field('image')['url']; ?>">
    <h3><?php the_title(); ?></h3>
</div>

<?php endwhile; ?>

</div>

</div>