<?php

namespace App\Fields;

use StoutLogic\AcfBuilder\FieldsBuilder;

class AgendaBlockFields
{
    public static function register()
    {
        $block = new FieldsBuilder('agenda_block_fields');

        $block
            ->setLocation('post_type', '==', 'page')

            ->addNumber('nombre_evenements', [
                'default_value' => 4
            ])
            ->addSelect('type_filtre', [
                'choices' => [
                    'tous' => 'Tous',
                    'vernissage' => 'Vernissage',
                    'rencontre' => 'Rencontre'
                ]
            ])
            ->addTrueFalse('afficher_grand', [
                'default_value' => 1
            ]);

        add_action('acf/init', function() use ($block) {
            acf_add_local_field_group($block->build());
        });
    }
}

AgendaBlockFields::register();