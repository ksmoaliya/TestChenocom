<?php

namespace App\Blocks;

class RegisterBlocks
{
    public static function register()
    {

        foreach (glob(get_theme_file_path('/blocks/*')) as $block) {
            if (file_exists($block . '/block.json')) {
                
                register_block_type($block);
            }

        }
    }
}
add_action('acf/init', [RegisterBlocks::class, 'register']);