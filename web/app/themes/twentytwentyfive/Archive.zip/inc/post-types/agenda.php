<?php

namespace App\PostTypes;

class AgendaPostType
{
    public static function register()
    {
        register_post_type('agenda', [
            'label' => 'Agenda',
            'public' => true,
            'menu_icon' => 'dashicons-calendar',
            'supports' => ['title', 'thumbnail'],
            'show_in_rest' => true,
            'has_archive' => true,
        ]);
    }
}

add_action('init', [AgendaPostType::class, 'register']);