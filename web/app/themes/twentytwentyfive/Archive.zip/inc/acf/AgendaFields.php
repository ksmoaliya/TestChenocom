<?php

namespace App\Fields;

use StoutLogic\AcfBuilder\FieldsBuilder;

class AgendaFields
{
    public static function register()
    {
        $agenda = new FieldsBuilder('agenda_fields');

        $agenda
            ->setLocation('post_type', '==', 'agenda')

            ->addDatePicker('date_debut', [
                'label' => 'Date début'
            ])
            ->addDatePicker('date_fin', [
                'label' => 'Date fin'
            ])
            ->addSelect('type_evenement', [
                'choices' => [
                    'vernissage' => 'Vernissage',
                    'rencontre' => 'Rencontre',
                    'patrimoine' => 'Patrimoine'
                ]
            ])
            ->addText('lieu')
            ->addText('ville')
            ->addWysiwyg('description')
            ->addImage('image');
        
        add_action('acf/init', function() use ($agenda) {
            acf_add_local_field_group($agenda->build());
        });
        
    }
}

AgendaFields::register();